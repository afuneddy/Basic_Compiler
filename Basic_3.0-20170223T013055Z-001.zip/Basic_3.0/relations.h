
#define REL_JEQ  1
#define REL_JNE  2
#define REL_JLT  3
#define REL_JLE  4
#define REL_JGT  5
#define REL_JGE  6

